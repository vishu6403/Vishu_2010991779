function myFunction(){
    var btn=document.getElementById("btn");
    var light=document.getElementById("Light");

     btn.classList.toggle("active");
     light.classList.toggle("on");
}



// Login JS:-

function Myfunction(){
    var a= document.getElementById("name").value;
    var b= document.getElementById("pass").value;

      if(a==""){
        document.getElementById("Username");
        alert("** Please Enter the Username **")
        return false;
      }
        if(b==""){
          document.getElementById("Password");
          alert("** Please Enter the Password **");
          return false;

        }
        else{
          alert("You logged in Successfully");
          window.location.href = ("lamps.html");
          return false;
        }
        
  }


  // Signup JS:

  function tofunction(){
    var c= document.getElementById("name1").value;
    var d= document.getElementById("pass1").value;
    var e= document.getElementById("email").value;
    var f= document.getElementById("phone").value;

    if(c==""){
      document.getElementById("Username");
      alert("** Please Enter the Username **")
      return false;
    }

    if(d==""){
      document.getElementById("Password1");
      alert("** Please Enter the Passwsord **")
      return false;
    }
    if(d.length <= 6){
      document.getElementById("Password1");
      alert("** Password must be more than 6 characters **")
      return false;
    }

    if(e==""){
      document.getElementById("Email");
      alert("** Please Enter the Email-ID **")
      return false;
    }

    if(f==""){
      document.getElementById("Phone");
      alert("** Please Enter the Contact No **")
      return false;
    }

    else{
      alert("You have registered successfully");
      window.location.href = ("lamps.html");
      return false;
    }


  }